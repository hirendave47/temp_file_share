
* Certs List for vWebServers:
- www.xforce-security.com
- license.xforce-security.com
- update.xforce-security.com
- www.cobion.com
- update.cobion.com
- license.cobion.com


vWebServers List:
- vWebserver01.xforce-security.com - 169.50.150.101	- 10.175.15.57
- vWebserver03.xforce-security.com - 169.60.230.252	- 10.93.49.150
- vWebserver06.xforce-security.com - 169.45.84.184	- 10.160.21.15
- vWebserver07.xforce-security.com - 169.50.150.98	- 10.175.15.53
- vWebserver08.xforce-security.com - 169.50.150.108	- 10.175.15.12


openssl pkcs12 -export -in www.xforce-security.com.crt -inkey www.xforce-security.com.key -out www.xforce-security.com.pfx -passout pass:

openssl pkcs12 -export -in license.xforce-security.com.crt -inkey license.xforce-security.com.key -out license.xforce-security.com.pfx -passout pass:

openssl pkcs12 -export -in update.xforce-security.com.crt -inkey update.xforce-security.com.key -out update.xforce-security.com.pfx -passout pass:

openssl pkcs12 -export -in www.cobion.com.crt -inkey www.cobion.com.key -out www.cobion.com.pfx -passout pass:

openssl pkcs12 -export -in update.cobion.com.crt -inkey update.cobion.com.key -out update.cobion.com.pfx -passout pass:

openssl pkcs12 -export -in license.cobion.com.crt -inkey license.cobion.com.key -out license.cobion.com.pfx -passout pass:

